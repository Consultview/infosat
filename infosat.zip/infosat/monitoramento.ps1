# ================= CONFIGURAÇÕES =================
$DIRETORIO_LOGS = "logs"
$PARALELISMO = 5
$INTERVALO_CICLO = 5

if (!(Test-Path $DIRETORIO_LOGS)) {
    New-Item -ItemType Directory -Path $DIRETORIO_LOGS | Out-Null
}

# ================= FUNÇÕES =================

function Expandir-Range {
    param ($entrada)

    if ($entrada -match "^(\d+\.\d+\.\d+\.)(\d+)-(\d+)$") {
        $prefixo = $matches[1]
        $inicio = [int]$matches[2]
        $fim = [int]$matches[3]

        if ($inicio -gt 255 -or $fim -gt 255 -or $inicio -gt $fim) {
            return "ERRO"
        }

        return ($inicio..$fim | ForEach-Object { "$prefixo$_" })
    }

    return $entrada
}

function Validar-IP {
    param ($ip)

    if ($ip -match "^(\d{1,3}\.){3}\d{1,3}$") {
        $oct = $ip -split "\."
        foreach ($o in $oct) {
            if ([int]$o -lt 0 -or [int]$o -gt 255) {
                return $false
            }
        }
        return $true
    }
    return $false
}

function Controlar-Jobs {
    while ((Get-Job -State Running).Count -ge $PARALELISMO) {
        Start-Sleep -Milliseconds 200
    }
}

# ================= SCRIPT DO JOB =================

$ScriptTeste = {
    param($alvo, $dir)

    $data = Get-Date -Format "dd/MM/yyyy HH:mm:ss"
    $arquivo = Join-Path $dir ("host_$($alvo -replace '\.', '_').log")

    if (!(Test-Path $arquivo)) {
@"
=======================================================================
RELATÓRIO DE MONITORAMENTO INFOSAT - $alvo
=======================================================================
DATA/HORA           | STATUS        | PERDA  | MÉDIA     | STDEV
-----------------------------------------------------------------------
"@ | Out-File $arquivo -Encoding UTF8
    }

    try {
        $pings = Test-Connection -ComputerName $alvo -Count 5 -ErrorAction Stop

        $enviados = 5
        $recebidos = $pings.Count
        $perda = [math]::Round((($enviados - $recebidos) / $enviados) * 100, 0)

        if ($recebidos -gt 0) {
            $avg = ($pings | Measure-Object ResponseTime -Average).Average

            $stdev = [math]::Sqrt(
                ($pings | ForEach-Object {
                    [math]::Pow($_.ResponseTime - $avg, 2)
                } | Measure-Object -Sum).Sum / $recebidos
            )

            if ($perda -eq 0) {
                $status = "EXCELENTE"
            }
            elseif ($perda -lt 100) {
                $status = "INSTÁVEL"
            }
            else {
                $status = "QUEDA TOTAL"
            }
        }
        else {
            $status = "QUEDA TOTAL"
            $avg = 0
            $stdev = 0
            $perda = 100
        }
    }
    catch {
        $status = "FALHA REDE"
        $avg = 0
        $stdev = 0
        $perda = 100
    }

    $linha = "$data | $status | $perda% | $([math]::Round($avg,2))ms | $([math]::Round($stdev,2))"
    Add-Content -Path $arquivo -Value $linha -Encoding UTF8

    return "$data|$alvo|$status|$avg|$perda"
}

# ================= LOOP PRINCIPAL =================

while ($true) {

    Clear-Host
    Write-Host "===============================================" -ForegroundColor Cyan
    Write-Host "   INFOSAT MONITORAMENTO POWERSHELL" -ForegroundColor Cyan
    Write-Host "===============================================" -ForegroundColor Cyan

    $limpar = Read-Host "Limpar logs? (s/n)"
    if ($limpar -eq "s") {
        Remove-Item "$DIRETORIO_LOGS\*.log" -ErrorAction SilentlyContinue
        Write-Host "Logs limpos!" -ForegroundColor Yellow
    }

    $IPS = @()

    while ($true) {
        $entrada = Read-Host "IP ou range (ENTER para continuar)"
        if ([string]::IsNullOrWhiteSpace($entrada)) { break }

        $alvos = Expandir-Range $entrada
        if ($alvos -eq "ERRO") {
            Write-Host "Range inválido" -ForegroundColor Red
            continue
        }

        foreach ($ip in $alvos) {
            if (Validar-IP $ip) {
                $IPS += $ip
                Write-Host "[+] $ip" -ForegroundColor Green
            }
        }
    }

    if ($IPS.Count -eq 0) { continue }

    $min = Read-Host "Minutos de teste"
    if (-not ($min -match "^\d+$")) { $min = 1 }

    $fim = (Get-Date).AddMinutes($min)

    Write-Host "`n--- INICIANDO MONITORAMENTO ---`n" -ForegroundColor Cyan

    while ((Get-Date) -lt $fim) {

        # dispara jobs com controle de paralelismo
        foreach ($ip in $IPS) {
            Controlar-Jobs
            Start-Job -ScriptBlock $ScriptTeste -ArgumentList $ip, $DIRETORIO_LOGS | Out-Null
        }

        # coleta segura de resultados
        $results = Get-Job | Wait-Job | Receive-Job -ErrorAction SilentlyContinue

        foreach ($r in $results) {

            if (-not $r -or $r -notmatch "\|") { continue }

            $p = $r -split "\|"
            if ($p.Count -lt 5) { continue }

            $data = $p[0]
            $alvo = $p[1]
            $status = $p[2]
            $avg = [math]::Round([double]$p[3],2)
            $perda = $p[4]

            switch ($status) {
                "EXCELENTE" { $cor = "Green" }
                "INSTÁVEL"  { $cor = "Yellow" }
                default     { $cor = "Red" }
            }

            Write-Host "[$data] $alvo | " -NoNewline
            Write-Host "$status " -ForegroundColor $cor -NoNewline
            Write-Host "| ${avg}ms | $perda%"
        }

        Get-Job | Remove-Job
        Start-Sleep -Seconds $INTERVALO_CICLO
    }

    # ================= RESUMO FINAL =================

    Write-Host "`n--- RESUMO FINAL ---" -ForegroundColor Yellow

    foreach ($ip in $IPS) {

        $arquivo = "$DIRETORIO_LOGS\host_$($ip -replace '\.', '_').log"
        if (!(Test-Path $arquivo)) { continue }

        $linhas = Get-Content $arquivo | Where-Object { $_ -match "\|" }

        $lat = @()
        $per = @()

        foreach ($l in $linhas) {
            $p = $l -split "\|"
            if ($p.Count -ge 4) {
                $lat += [double]($p[3] -replace "ms","")
                $per += [int]($p[2] -replace "%","")
            }
        }

        $media = if ($lat.Count) { ($lat | Measure-Object -Average).Average } else { 0 }
        $pior = if ($per.Count) { ($per | Measure-Object -Maximum).Maximum } else { 0 }

        $final = if ($pior -lt 5) { "APROVADO" } else { "REVISÃO" }

        Write-Host "`nIP: $ip"
        Write-Host "Média: $([math]::Round($media,2)) ms"
        Write-Host "Perda: $pior %"
        Write-Host "Status Final: $final"
        Write-Host "-----------------------------------"
    }

    Read-Host "ENTER para reiniciar"
}
